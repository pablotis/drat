#' Available locales
#'
#' A subset of available locales in makeup package
#'
#' @format ## `available_locales`
#' A vector with 61 values
#'
"available_locales"
