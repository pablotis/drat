## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----library------------------------------------------------------------------
library(makeup)

## ----num example--------------------------------------------------------------
x <- c(1234.56, 432141, 0.12)

makeup(x, 
       sample = "1,432.1")

## ----chr example--------------------------------------------------------------
x <- c("hello", "WoRlD","Hello world")

makeup(x, sample = "down")

makeup(x, sample = "UPPER")

makeup(x, sample = "Title phrase")

makeup(x, sample = "Title Case")

## ----date example-------------------------------------------------------------
x <- as.Date(c("2020-03-05","2020-06-20"))

makeup(x)

