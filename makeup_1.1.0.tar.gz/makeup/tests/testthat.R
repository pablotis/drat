library(testthat)
library(makeup)

test_check("makeup")
